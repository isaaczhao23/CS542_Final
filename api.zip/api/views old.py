from django.shortcuts import render
from django.http import JsonResponse
from rest_framework.decorators import api_view
from rest_framework.response import Response
from .serializers import *
from .models import *

# Create your views here. https://www.youtube.com/watch?v=TmsD8QExZ84&list=WL&index=3&t=724s

@api_view(['GET'])
def apiOverview(request):
	api_urls = {
		'List':'/task-list/',
		'Detail View':'/task-detail/<str:pk>/',
		'Create':'/task-create/',
		'Update':'/task-update/<str:pk>/',
		'Delete':'/task-delete/<str:pk>/',
		}
	return Response(api_urls)

# RETRIEVE ALL RECORDS FOR ONE DATASET
# api/task-list/
@api_view(['GET'])
def taskList(request):
	#tasks = DbUser.objects.all().order_by('-user_id')
	tasks = DbUser.objects.all()
	serializer = DbUserSerializer(tasks, many=True)
	return Response(serializer.data)

# RETRIEVE ONLY ONE RECORD FOR ONE DATASET
# api/task-detail/1/
@api_view(['GET'])
# pk is passing primary key
def taskDetail(request, pk):
	tasks = DbUser.objects.get(id=pk)
	# many=False means return only one object that is queried
	serializer = DbUserSerializer(tasks, many=False)
	return Response(serializer.data)

# some people use postman instead
@api_view(['POST'])
def taskCreate(request):
	# since api_view, we have acess to request.data. otherwise use request.POST. request.data returns json object
	serializer = DbUserSerializer(data=request.data)
	# if valid, save to database
	if serializer.is_valid():
		serializer.save()
	return Response(serializer.data)

@api_view(['POST'])
def taskUpdate(request, pk):
	task = DbUser.objects.get(id=pk)
	serializer = DbUserSerializer(instance=task, data=request.data)
	if serializer.is_valid():
		serializer.save()
	return Response(serializer.data)

# api/task-delete/1/
@api_view(['DELETE'])
def taskDelete(request, pk):
	task = DbUser.objects.get(id=pk)
	task.delete()
	return Response('Item succsesfully delete!')


# javascript makes call to backend
