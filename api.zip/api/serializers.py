from rest_framework import serializers
from .models import *

# allow to work with json
class DbUserSerializer(serializers.ModelSerializer):
	class Meta:
		model = DbUser
		fields ='__all__'
		#fields = ('var1','var2')
