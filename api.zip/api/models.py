from django.db import models
#from django.utils.translation import ugettext_lazy as _


class DbUser(models.Model):
    user_id = models.CharField(primary_key=True, max_length=9,blank=True,null=True)
    ssn = models.CharField(unique=True, max_length=9, blank=True, null=True)
    fname = models.CharField(max_length=20, blank=True, null=True)
    lname = models.CharField(max_length=20, blank=True, null=True)
    username = models.CharField(unique=True, max_length=60, blank=True, null=True)
    password = models.CharField(max_length=60, blank=True, null=True)
    dob = models.DateField(blank=True, null=True)
    phone_number = models.CharField(unique=True, max_length=12, blank=True, null=True)
    state = models.CharField(max_length=2, blank=True, null=True)
    city = models.CharField(max_length=30, blank=True, null=True)
    street = models.CharField(max_length=50, blank=True, null=True)
    gender = models.CharField(max_length=1, blank=True, null=True)
    race = models.CharField(max_length=50, blank=True, null=True)

    def clean(self):
        if self.user_id:
            self.user_id = self.user_id.strip()

    def clean(self):
    for field in self._meta.fields:
        if isinstance(field, (models.CharField, models.TextField)):
            setattr(self, field.name, getattr(self, field.name).strip())

    class Meta:
        managed = False
        db_table = 'db_user'

